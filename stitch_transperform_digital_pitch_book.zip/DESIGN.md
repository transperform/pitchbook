---
name: Swiss Precision Consulting
colors:
  surface: '#fbf9f9'
  surface-dim: '#dbdad9'
  surface-bright: '#fbf9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#e9e8e7'
  surface-container-highest: '#e3e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#5e3f3b'
  inverse-surface: '#303031'
  inverse-on-surface: '#f2f0f0'
  outline: '#936e69'
  outline-variant: '#e9bcb6'
  surface-tint: '#c0000c'
  primary: '#b5000b'
  on-primary: '#ffffff'
  primary-container: '#e30613'
  on-primary-container: '#fff5f3'
  inverse-primary: '#ffb4aa'
  secondary: '#5f5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e4e2e2'
  on-secondary-container: '#656464'
  tertiary: '#0059a8'
  on-tertiary: '#ffffff'
  tertiary-container: '#0071d4'
  on-tertiary-container: '#f5f7ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4aa'
  on-primary-fixed: '#410001'
  on-primary-fixed-variant: '#930007'
  secondary-fixed: '#e4e2e2'
  secondary-fixed-dim: '#c8c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#474747'
  tertiary-fixed: '#d5e3ff'
  tertiary-fixed-dim: '#a7c8ff'
  on-tertiary-fixed: '#001b3c'
  on-tertiary-fixed-variant: '#004788'
  background: '#fbf9f9'
  on-background: '#1b1c1c'
  surface-variant: '#e3e2e2'
  swiss-red: '#E30613'
  charcoal-dark: '#444444'
  charcoal-medium: '#777777'
  surface-light: '#F7F7F7'
  pure-white: '#FFFFFF'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-desktop: 80px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style
The design system embodies the "Swiss Style" of graphic design—prioritizing cleanliness, readability, and objectivity. It is tailored for a high-end consulting environment where precision meets human-centric transformation. The aesthetic is professional and authoritative, yet avoids corporate sterility through the strategic use of vibrant red accents and high-quality photography.

The visual direction is **Minimalist & Professional**. It relies on a rigorous grid, generous white space, and a refined typographic hierarchy to convey reliability. It avoids unnecessary decoration, ensuring that the expertise of the consultant remains the focal point. Elements are structured to feel deliberate, stable, and meticulously engineered.

## Colors
The palette is rooted in a traditional Swiss aesthetic: a high-impact "Swiss Red" balanced against sophisticated neutrals. 

- **Primary (Swiss Red):** Used sparingly for calls to action, critical highlights, and brand markers. It signifies energy and precision.
- **Secondary (Charcoal Dark):** Replaces pure black for all primary text and structural elements, offering a softer, more premium feel while maintaining high contrast.
- **Neutral (Charcoal Medium):** Reserved for secondary text and borders.
- **Backgrounds:** The interface primarily utilizes **Pure White** to maximize whitespace, with **Surface Light** used for subtle section differentiation or container backgrounds.

Color application must follow a 60-30-10 rule: 60% White, 30% Charcoal, and 10% Red to maintain professional restraint.

## Typography
Typography is the cornerstone of this design system. We utilize **Hanken Grotesk** for headlines to provide a sharp, contemporary edge that feels more distinctive than standard neo-grotesques. **Inter** is used for body copy due to its exceptional legibility and neutral character.

- **Headlines:** Should be set with tight letter-spacing and substantial leading. Large display type is encouraged for hero sections to create impact.
- **Body Text:** Maintains a comfortable line height (1.5x - 1.6x) to ensure readability in long-form consulting reports or articles.
- **Labels:** Small caps or all-caps with increased tracking are used for overlines and micro-copy to provide a structured, architectural feel.

## Layout & Spacing
The layout follows a strict **12-column fixed grid** on desktop (max-width 1280px) and a **4-column fluid grid** on mobile. 

- **Whitespace:** Emphasize "Active Whitespace." Sections should be separated by large gaps (`section-gap`) to allow the content to breathe and signify a change in topic.
- **Alignment:** Consistent left-alignment is preferred to reinforce the Swiss aesthetic. Avoid centered text for body copy.
- **Rhythm:** All spacing (padding, margins) must be multiples of the 8px base unit to maintain mathematical harmony across the UI.

## Elevation & Depth
In keeping with the minimalist philosophy, this design system avoids heavy drop shadows. Depth is conveyed through **Tonal Layers** and **Low-contrast Outlines**.

- **Surfaces:** Use `#F7F7F7` to pull content forward against a `#FFFFFF` background.
- **Borders:** Use 1px solid lines in `#D1D1D1` (light grey) for cards and section dividers.
- **Interactive Depth:** Only use subtle, highly diffused shadows (e.g., `0 4px 20px rgba(0,0,0,0.05)`) on hover states to provide tactile feedback without cluttering the visual plane.

## Shapes
Shapes are disciplined and functional. We use a **Soft (0.25rem)** corner radius for most components to prevent the UI from feeling aggressive, while maintaining the "precise" look of a consulting firm.

- **Buttons & Inputs:** Use the base `0.25rem` radius.
- **Containers:** Large cards or feature blocks may use `0.5rem` (rounded-lg) for a more approachable, human-centric feel.
- **Icons:** Use linear, medium-weight icons with square ends to match the typographic precision.

## Components
- **Buttons:** Primary buttons are solid `Swiss Red` with white text. Secondary buttons use a `Charcoal Dark` outline with no fill. Always use rectangular shapes with subtle rounding; never pills.
- **Input Fields:** Use a simple 1px bottom border or a full subtle outline. Focus states should use a 2px `Swiss Red` bottom accent.
- **Cards:** Cards should be flat with a 1px border or a very light grey background. Do not use shadows by default; only on hover.
- **Chips/Badges:** Small, all-caps text with a light grey background (`#F7F7F7`) and no border.
- **Imagery:** Use high-resolution, candid business photography. Focus on human interaction, natural lighting, and "work-in-progress" consulting sessions. Images should be framed with sharp edges or the standard `0.25rem` radius.
- **Lists:** Use custom red square bullets instead of standard dots to reinforce brand identity.